---
name: director-console
description: Operate the Mochuan Director Console (MiniMax H3 / Z-Image / IndexTTS 2.5) through its local HTTP Agent API. Use when reading or creating scripts, creating projects, generating single-shot or batch videos, using AI screenwriting, AI image generation, AI voiceover, or managing assets and logs. Also includes MiniMax H3 prompt-writing rules.
compatibility: Any agent that can read local files and send HTTP requests (Codex, OpenClaw, DeepSeek Harness, etc.). No external runtime required.
---

# 墨川导演台 Agent 操作技能

## 1. 服务与鉴权

- 导演台本地服务地址：`http://127.0.0.1:8199`
- Agent token 文件：项目根目录 `agent_token.json`，读取其中 `token` 字段。
- 所有 `/api/agent/v1/*` 请求必须携带请求头：`X-Agent-Token: <token>`（也支持 `Authorization: Bearer <token>`）。
- 接口规范：`GET /api/agent/v1/openapi.json`（稳定 Agent 入口）和 `GET /api/openapi.json`（完整版）。不确定字段时先读规范，不要猜。
- 授权拦截：未授权时 `/api/*` 返回 HTTP 403 且 `license_blocked: true`；`/director` 页面返回 403 拦截页。遇到该状态先提示用户通过官方启动器授权。


## 1.1 本地 / 云端推理模式

导演台支持 `local`（本机 ComfyUI `127.0.0.1:8188`）与 `cloud`（SSH 隧道到已部署云端 ComfyUI）两种推理位置。任何生成操作前先检测，不要默认只连本地 8188。

检测可用性：

```powershell
$m = Invoke-RestMethod -Headers $headers -Uri "http://127.0.0.1:8199/api/clouddeploy/mode"
```

- `local_available`：本地 ComfyUI 是否可用。
- `cloud_deployed`：云端是否已部署。
- `cloud_comfy_ready`：云端 ComfyUI 是否可推理。
- `cloud_tunnel_active`：云端隧道是否已建立。

推理位置判断：

1. 仅本地：`local_available=true` 且 `cloud_comfy_ready=false` → `runtime="local"`。
2. 仅云端：`local_available=false` 且 `cloud_comfy_ready=true` → `runtime="cloud"`，不要尝试本地 8188。
3. 本地与云端都有：两者均可用时读取全量 state 的 `defaultRuntime`；用户对某个分镜/任务明确指定 `runtime` 时以指定为准。
4. 都不可用：报告“本地/云端 ComfyUI 均不可用”，停止生成。

写入 runtime 的方式：

- 单镜视频：`POST /api/agent/v1/generate/single` body 增加 `"runtime":"local|cloud"`。
- 批量视频：先 `GET /api/agent/v1/state`，只修改目标 `shots[].runtime`（必要时修改 `defaultRuntime`），原样写回 `POST /api/agent/v1/state`，再执行批量生成。禁止用全量 state 写 `shotCards` 或剧本字段。
- AI 制图：`POST /api/agent/v1/image/generate` body 增加 `"runtime":"local|cloud"`。
- AI 配音：`POST /api/agent/v1/tts/generate` body 增加 `"runtime":"local|cloud"`。

批量生成仍严格串行；本地队列与云端队列由后端调度，Agent 侧不要并发重复提交同一批分镜。
## 2. 数据模型

全量状态由 `GET /api/agent/v1/state` 返回，顶层键：`projects`、`scripts`、`shots`、`scriptShots`、`assets`、`audio`、`settings`。

### 2.1 剧本 script（剧本库条目 / 剧本详情顶部）

`id, title, genre, desc, world, conflict, summary, scenes, shots, duration, icon, cover, updated, updatedAt`

- `genre` 剧本类型，`desc/summary` 梗概，`world` 世界观，`conflict` 冲突主线。

### 2.2 剧本分镜 scriptShot（剧本详情页每个分镜卡片）

`id, scriptId, episode, scene, num, title, type, dur, assets, audioRefs, negative, style, sceneEnv, audio, plot, dialogue, directorNote, shotCards, start, end, promptMode, h3PromptRaw, h3PromptRawEn, h3PromptSource, h3PromptNotes`

- `scene` 场次，`num` 镜号（如 `1.1`、`2.3`），`title` 分镜标题。
- `episode` 整数剧集号，默认 `1`；`num` 写作 `剧集.镜序号`（如第一集第 3 镜写 `1.3`，第二集第 3 镜写 `2.3`）。同一剧集内镜序号从 1 连续递增，新开一集时从 1 重新开始。
- `type` 景别，`dur` 时长（秒）。
- `assets` 关联角色/场景/道具资产 id 列表（不是资产名）。
- `audioRefs` 参考音频 id 列表。
- `negative/style/sceneEnv/audio/plot/dialogue/directorNote` 分别对应负面提示、视频风格、场景环境、环境音效、剧情、台词、导演提示；其中 `negative` 必须留空，MiniMax H3 无负面通道，只有 Seedance / Z-Image 的画面质量意图才允许由系统内部使用，AI 编剧与 Agent 不写。
- `shotCards` 镜头段列表（卡片式）。
- `promptMode` 提示词模式：`cards`（卡片式，默认）或 `six`（六段式）。详见 §6.2。
- `h3PromptRaw` 六段式原文（中英文都行）；`h3PromptRawEn` 英文版；`h3PromptSource` 来源（`ai`/`user-en`/`user-zh`）；`h3PromptNotes` 翻译/润色说明。

### 2.3 镜头段 shotCard（分镜内的分段卡片）

`id, startSec, endSec, shotSize, camera, movement, staging, plot, action, dialogue`

- `shotSize` 景别，`camera` 机位，`movement` 运镜，`staging` 站位角度，`plot` 剧情/画面事件，`action` 人物动作/表演。
- `dialogue`：`{speaker, line, lang, position, anchor, voiceId}`
  - `speaker` 说话人（用 `@角色名`），`line` 台词文本，`lang` 语言（默认 `zh`）。
  - `position` 台词时机（前段/中段/后段等），`anchor` 动作锚点，`voiceId` 绑定参考音色 id。

### 2.4 项目 project 与项目分镜 shot

project：`id, scriptId, title, status, statusText, progress, shotsDone, shotsTotal, resolution, aspectRatio, steps, lowVram, refImageSize, workflow`

shot：`id, projectId, scriptShotId, scene, num, title, type, dur, frames, assets, refs, negative, style, sceneEnv, audio, plot, dialogue, directorNote, shotCards, prompt, start, end, firstFrame, lastFrame`

- 项目以剧本为模板创建；`shot` 由 `scriptShot` 复制并计算 `start/end` 时间轴。

### 2.5 分集、分镜与镜头段的关系

- `shots` / `scriptShots` 数组长度 = 实际“分镜”数量。一个 `shot` 对应一个分镜；`shotCards` 是单个分镜内部的“镜头段/子镜头”，不是新分镜。
- 复制/插入分镜只影响同一剧集；批量替换、批量翻译、AI 润色作用于全部剧集。写回 `scriptShots` 必须带上 `episode`，并保持 `num` 与 `episode` 一致。
- 用户说“1 个分镜 + 多个镜头段”时，结果是 `len(shots) == 1`，多个 `shotCards` 放在该分镜内；用户说“3 个分镜”时才是 3 个 `shots`。最新明确指令优先。

## 3. 常用 Agent 接口

- `GET /api/agent/v1/openapi.json`：稳定 Agent OpenAPI。
- `GET /api/agent/v1/auth/status`：授权状态。
- `GET /api/agent/v1/models/pipelines`：可用模型/管线。
- `GET /api/agent/v1/state`：读取全量状态。
- `POST /api/agent/v1/state`：整份状态写入（危险，尽量不用整份覆盖，优先用下面的专用接口）。
- `GET /api/agent/v1/scripts`：剧本列表（含 `shot_count`）。
- `GET /api/agent/v1/scripts/{script_id}`：剧本详情 + `shots` 列表。
- `POST /api/agent/v1/scripts/apply`：创建/覆盖剧本并同步关联项目。
- `POST /api/agent/v1/scripts/import`：导入剧本（multipart 表单字段 `file`，支持 `.xlsx` / `.csv`）。
- `GET /api/agent/v1/projects` / `GET /api/agent/v1/projects/{project_id}`：项目列表/详情。
- `POST /api/agent/v1/projects`：从剧本创建项目。
- `POST /api/agent/v1/generate/single`：单镜生成视频。
- `POST /api/agent/v1/generate/batch`：批量生成视频。
- `GET /api/agent/v1/generate/status?scope=single|batch`：轮询生成状态。
- `POST /api/agent/v1/generate/stop`：停止生成，`{"scope": "single"|"batch"|"all"}`。
- `POST /api/agent/v1/ai/chat`：AI 编剧对话（非流式）。
- `POST /api/agent/v1/ai/draft`：AI 编剧生成结构化草稿（推荐，非流式稳定）。
- `POST /api/agent/v1/ai/apply`：应用 AI 草稿到剧本。
- `GET /api/agent/v1/image/status` / `POST /api/agent/v1/image/generate` / `POST /api/agent/v1/image/unload` / `DELETE /api/agent/v1/image/delete`：AI 制图（Z-Image）。
- `POST /api/agent/v1/tts/generate` / `GET /api/agent/v1/tts/status`：AI 配音（IndexTTS 2.5）。
- `GET /api/agent/v1/assets`：资产列表。
- `GET /api/agent/v1/logs?kind=comfyui|h3|ai|seedance|minimaxh3|tts`：实时日志。

## 4. 直接在导演台生成新剧本（推荐流程）

1. 构造剧本草稿 JSON（结构见下）。
2. `POST /api/agent/v1/scripts/apply`，请求体 `{"draft": <剧本草稿>, "scriptId": ""}`。
   - 不传或空 `scriptId` 会新建剧本；传已有 `scriptId` 则覆盖该剧本并按镜号同步项目。
3. 用返回的 `scriptId` 创建项目：`POST /api/agent/v1/projects`，请求体 `{"scriptId": "<id>", "resolution": "720p", "aspectRatio": "16:9 (Widescreen)", "steps": 4, "lowVram": false}`。
4. 批量生成：`POST /api/agent/v1/generate/batch`，请求体 `{"projectId": "<project_id>", "shotIds": [], "delaySeconds": 0}`。
5. 轮询 `GET /api/agent/v1/generate/status?scope=batch` 直到完成；单镜用 `scope=single`。

### 剧本草稿 draft JSON 结构（必须写满字段）

**禁止用 `POST /api/agent/v1/state` 写剧本。**

**剧本库中的历史剧本只能作为剧情参考，不能作为字段完整性的模板；旧剧本可能因为早期写入方式而缺少机位/运镜/站位/动作。写新剧本一律以本规范为准，所有 shotCard 关键字段必须写满。**
 创建/覆盖剧本只允许 `POST /api/agent/v1/scripts/apply`，请求体 `{"draft": <下面结构>, "scriptId": ""}`；或先 `POST /api/agent/v1/ai/chat` 生成草稿，再 `POST /api/agent/v1/ai/apply`。

```json
{
  "title": "山道寻医",
  "genre": "剧情",
  "desc": "流浪汉带受伤的狗沿山路寻找药店。",
  "world": "现代中国山野，土路、溪流、小药店。",
  "conflict": "旅途中的自然危险、陌生人的冷漠与一人一狗的相互守护。",
  "summary": "流浪汉与阿毛穿越山野，最终到达药店，阿毛获救。",
  "shots": [
    {
      "scene": "第1场 · 晨雾山路",
      "num": "1.1",
      "title": "阿毛回头等人",
      "type": "全景",
      "dur": 8,
      "assets": ["@流浪汉", "@阿毛"],
      "audioRefs": [],
      "negative": "",
      "style": "现代写实风格，贴近现实生活，不要影视效果",
      "sceneEnv": "清晨薄雾笼罩的荒野土路，两侧碎石枯草，远处山脊若隐若现，地面露水反光",
      "audio": "山风低沉呼啸、脚步踩碎石声、远处野鸟鸣叫",
      "plot": "流浪汉沿碎石土路缓步前行，阿毛在前方小跑并回头等待。",
      "dialogue": "流浪汉说：阿毛，慢点。",
      "directorNote": "略低机位全景；固定镜头缓慢前推；主光为清晨冷光，辅光为天光，轮廓光勾边；色温偏冷灰蓝；色调低饱和青灰；剪辑叠化到下一镜中景。",
      "shotCards": [
        {
          "startSec": 0,
          "endSec": 3,
          "shotSize": "全景",
          "camera": "略低机位平拍",
          "movement": "缓慢推镜头",
          "staging": "流浪汉在前景偏左，阿毛在前方偏右，两人视线方向与机位形成纵深感",
          "plot": "流浪汉背着帆布包袱沿碎石路前行，阿毛在前面小跑，尾巴轻摆。",
          "action": "流浪汉脚步稳定，阿毛偶尔回头，耳朵竖起。",
          "audioRefs": [],
          "videoRef": "",
          "dialogue": {"speaker": "@流浪汉", "line": "阿毛，慢点。", "lang": "zh", "position": "during", "anchor": "阿毛回头", "voiceId": ""}
        }
      ]
    }
  ]
}
```

硬性规则：

- `shots` 也可以写成 `scriptShots`；但每个 `shot` 必须有非空 `shotCards`，不允许只给 `plot` 让后端自动拆段。
- 所有 `shotCards` 时间段首尾相接、总和等于 `dur`；单段不超过 4 秒。8 秒至少 3 段，10-15 秒至少 4-5 段，20 秒至少 5-6 段，20-60 秒至少 6-15 段（单段仍不超过 4 秒）。
- 每张 `shotCard` 的 `shotSize / camera / movement / staging / plot / action` 必须全部非空；仅 `audioRefs / videoRef / dialogue.line / voiceId` 允许为空。
- `shotSize` 优先使用：大远景、远景、全景、中景、近景、特写、大特写。
- `camera` 写机位高度与角度；`movement` 写运镜；`staging` 写站位角度与构图关系，不能只复制 `plot`。
- `plot` 只写画面事件；`action` 写外部可见的人物动作、表情、视线、肢体表演。
- `plot / staging / action` 禁止“谁都不肯、心想、决定、觉得、似乎、仿佛、几乎无法分辨、咬牙坚持、不甘、旁白、解说”等小说式叙述句；必须写“谁 + 身体部位 + 动作 + 对象 + 结果”。
- `dialogue.speaker` 必须统一用 `@角色名`，并与该镜 `assets` 一致；`line` 无台词就写空字符串；`position` 只能是 `before / during / after`；`anchor` 写动作锚点。
- `negative` 必须写空字符串 `""`；AI 编剧与 Agent 都不要写任何“禁止 / 不要 / 无 / 避免”负面内容。
- `directorNote` 必须写全 6 项：机位高度与角度、镜头类型与运动、主光/辅光/轮廓光、色温明暗、色调参考、剪辑衔接。
- `assets` 只填该镜真正出现的 `@角色名` / `@场景名`；`audioRefs` 有参考音色才填 `@音频名`，没有就 `[]`。

## 5. 剧本详情页面结构（中文标签 → 字段）

- 剧本信息：剧名 `title`、类型 `genre`、梗概 `desc`、世界观 `world`、冲突 `conflict`、故事摘要 `summary`。
- 分镜卡片：镜号 `num`、分镜标题 `title`、场次 `scene`、景别 `type`、时长 `dur`、关联资产 `assets`、参考音频 `audioRefs`。
- 提示词分区：负面 `negative`、视频风格 `style`、场景环境 `sceneEnv`、环境音效 `audio`、剧情 `plot`、台词 `dialogue`、导演提示 `directorNote`。
- 镜头段（分段）：景别 `shotSize`、机位 `camera`、运镜 `movement`、站位角度 `staging`、剧情/画面事件 `plot`、人物动作/表演 `action`、说话人 `dialogue.speaker`、时机 `dialogue.position`、动作锚点 `dialogue.anchor`、语言 `dialogue.lang`、音色 `dialogue.voiceId`、台词 `dialogue.line`。

### 固定词表（填写时优先使用，也可手写）

- 景别：大远景、远景、全景、中全景、中景、中近景、近景、特写、大特写、极特写、空镜、主观镜头、过肩镜头、双人镜头、三人镜头、群像镜头、插入镜头、切出镜头、反应镜头、环境远景、人物全景。
- 机位：平拍、俯拍、仰拍、正拍、侧拍、斜侧机位、背面机位、低机位、高机位、肩后机位、过肩机位、贴地机位、航拍机位、升降机位、摇臂机位、手持机位、固定机位、桌面机位、车内机位、监控视角。
- 运镜：固定镜头、推镜头、拉镜头、摇镜头、移镜头、跟镜头、升降镜头、甩镜头、环绕镜头、横移、纵移、手持晃动、呼吸感手持、斯坦尼康跟拍、航拍前进、航拍后退、快速变焦、慢推、快摇、360度环绕、荷兰角、希区柯克变焦、虚实变焦。

## 6. MiniMax H3 提示词规则

- 有 API 翻译时：`subject_definitions/summary/retention_analysis/detailed_description/overall_soundscape/non_diegetic_music` 等结构化字段全英文；对白、歌词、可见场景文字保留原语言并包在 `<d>[语言] 文本</d>` 中。
- 没有可用 API 时：剧情 `plot`、场景 `sceneEnv` 直接保留中文，不回退成通用英文动作描述；结构化字段（景别/机位/运镜等固定词）仍按内置映射输出英文。
- `plot`/`staging`/`action` 只能写镜头可拍摄的物理动作，禁止“谁都不肯/不愿/心想/决定/觉得/似乎/仿佛/几乎无法分辨/咬牙坚持/不甘/旁白/解说”等小说式叙述句；H3 本地 Base 会把这类句子念成旁白，无台词镜头尤其必须物理化。
- 角色/场景参考图必须写进 `subject_definitions` 和 `retention_analysis`，锁身份、锁服装、锁环境；场景参考图只能当背景，不能当成角色。
- 详细格式与示例见 `references/base-en.txt`（T2VA/I2VA/FL2VA/L2VA）和 `references/ref-en.txt`（全参考 Ref2VA 六段式）。

### 6.1 官方硬规则（MiniMaxAI/MiniMax-H3 官方 skill，生成前逐条核对）

- 先识别模式：T2VA / I2VA / FL2VA / L2VA / Ref2VA。基础模式字段顺序固定为 `integrated_multimodal_description` → `overall_soundscape` → `non_diegetic_music`；Ref2VA 六段顺序固定为 `subject_definitions` → `summary` → `retention_analysis` → `detailed_description` → `overall_soundscape` → `non_diegetic_music`。
- 除对白、歌词、画面里可见文字保留原语言并包 `<d>` 外，结构化字段全部写英文。总时长必须匹配请求时长；生成任务时长通常 4–15 秒，最长 60 秒，Ref2VA 的 `detailed_description` 通常 350–500 英文词。
- 关键帧指令必须放在 prompt 第一行，且与三核心字段之间空一行。I2VA：`For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.`；FL2VA：首帧对齐 `0.00` 秒、末帧对齐 `S.SS` 秒；L2VA：`<Picture 1>` 对齐视频末帧。T2VA 不加对齐指令。
- `[Shot 1]` 开头不带时间戳；后续镜头用严格递增且落在视频时长内的切点，如 `[Shot 2] At 00:03.500, the camera cuts to...`。普通剪辑只用 `the camera cuts to / the shot cuts to / the shot transitions to / the shot changes to / the shot switches to`，除非用户明确要求才用 dissolve/fade/wipe。
- 相机运动写自然英文句，包含运动类型、幅度、速度三要素：`The camera pushes in with small amplitude at slow speed...`；不要只在句尾堆标签。相邻镜头角度差至少 30°，保持 180° 轴线。
- 音轨必须分层：同步到某镜的对白、歌唱、音效写进 `integrated_multimodal_description` 或 `detailed_description`；全片环境声、物理动作声、非语言人声写进 `overall_soundscape`；只有观众能听见的配乐写进 `non_diegetic_music`。不要把对白/歌词重复写进声音字段。
- **无配乐时 `non_diegetic_music: N/A`，不要写 “No background music, no melody, no score.” 这类规则描述。** 有配乐时写乐器、速度、动态发展，例如 `A restrained solo-piano score at a slow tempo, with sustained low cello underneath and no swell.`
- `overall_soundscape` 一般写 1–4 句，普通无配乐不等于静音，不能写 `N/A`；只有用户明确要求“完全静音、没有任何声音”时才能 `overall_soundscape: N/A`。
- H3 没有负面词通道：不要把 “No subtitles / no narration / no background music” 等否定短语写进提示词；无字幕、无旁白、无背景音乐靠 `overall_soundscape` 只写非语言环境声、`non_diegetic_music: N/A`、无对白时 `dialogue.line=""` 实现。
- 参考音频的复制/参考关系写到对应音频层：ambience/fx 写 `overall_soundscape`，配乐写 `non_diegetic_music`；同一条音频同时提供两层时两节都写。复制关系用 `fully_copy / partially_copy`，参考关系用 `reference / weak_reference`。
- 标签必须全文一致：`<Subject N>` 可复用内容，`<Picture N>` 帧/构图锚点，`<Video N>` 整段视频关系，`<Audio N>` 音频复制或参考。图片只用来定义角色/场景时写进 `<Subject N>`，不要重复单列 `<Picture N>`。
- 说话人用稳定 `(Sx)`，按实际发声顺序分配；参考主体说话写 `<Subject N> (Sx)`。直接复用的歌词/对白保留原文，听不清写 `[unclear]`，不猜测。跨剪对话、片尾截断、跨镜连续声音使用官方对应的 `<scenetrans>`、`<cutoff>` 与连续描述。

### 6.2 提示词模式：卡片式 / 六段式（外置 Agent 必读）

剧本有 `promptMode` 字段：`cards`（默认，卡片式）或 `six`（六段式）。

**参考图绑定（六段式必写）**：H3 不认识人名，只认标签。图片按挂载顺序就是
`<Picture 1..N>`，`<Subject N>` 只有在定义行里点名取自哪张 `<Picture N>` 时才有身份来源。
所以六段式的 `subject_definitions` 每一行都要写绑定，例如
`<Subject 1> 是李雷，身份参考 <Picture 1>，只锁脸、发型、五官比例与衣着。`。
只写「`<Subject 1>` 是李雷」而不写 `<Picture 1>`，模型只能靠挂图顺序猜谁是谁，
典型症状就是「衣服像、脸不像 / 换人 / 双胞胎」。`<Picture N>` 编号必须与实际挂图顺序一致。

**强制交互条款**：Codex / OpenClaw / DeepSeek harness 等外部智能体在开始写分镜之前，
**必须先问用户**「这一部用卡片式还是六段式？」。用户没有明确回答之前：

- 不要写 `shotCards`；
- 不要写 `h3PromptRaw`；
- 只可以先做剧情梗概、场次、资产清单等不依赖模式的前期工作。

用户选完之后再按对应模式写，并把 `promptMode` 一起写进剧本草稿（剧本级）。

**沿用条款（对已有剧本 apply 时强制）**：

- **不得擅自改模式**：已有剧本的 `promptMode` 只能由用户改。用户没要求换模式时，
  draft 里就不要写 `promptMode`；写了才会覆盖，不写由导演台沿用原值（不会退回 `cards`）。
- **不得清空手写正文**：draft 里没写 `h3PromptRaw` / `h3PromptRawEn` / `h3PromptSource` /
  `h3PromptNotes` 时，这些字段沿用原值；只有你显式写了才覆盖。不要为了“补字段”传空字符串。
- **覆盖前先报账**：提交 `apply` 之前，先在回复里说明「本次覆盖哪些字段、哪些字段沿用原值」，
  让用户能在页面拨片上确认模式没被切换。
- **模式与字段配套**：`cards` 只写 `shotCards`，`six` 只写 `h3PromptRaw`（及英文版），
  不要在同一份 draft 里两种都写。

#### 卡片式（promptMode="cards"）

沿用 §2.3 的 `shotCards`：每镜按时间轴拆镜头段，写满
`shotSize / camera / movement / staging / plot / action`，台词写进 `dialogue`。
导演台会把这些字段拼成官方英文六段提示词。

#### 六段式（promptMode="six"）

用户直接写 MiniMax H3 官方全参考（Ref2VA）六段提示词，中英文都可以，**顺序不限**：

```
subject_definitions:
summary:
retention_analysis:
detailed_description:
overall_soundscape:
non_diegetic_music:
```

- 存放字段：`h3PromptRaw`（用户原文）；也可以把英文版写进 `h3PromptRawEn`，
  来源写进 `h3PromptSource`（`ai` / `user-en` / `user-zh`）。
- 每个分镜一个 `h3PromptRaw`，与 `dur`（秒）一一对应。
- **合并模式（默认开）**：用户写了的段用用户的，没写的段由导演台自动补全
  （`<Subject N>` 定义、`retention_analysis`、首行关键帧指令、task-type 前缀）。
  所以 Agent 不必每段都写，但写了就按你的来。
- 六段式下 `assets` / `audioRefs` 仍然要填，自动补全的参考图绑定靠它。
- 首帧 / 首+尾帧 / 上下 22 帧衔接指令由导演台按绑定自动生成；
  如果用户要自己写，只能写在 prompt 第一行，且 `<Picture N>` 编号必须排在参考图编号之后
  （已绑 N 张参考图时从 N+1 开始），否则开头会闪参考图。
- 台词固定写 `<d>[语言] 台词</d>`（语种用英文名 `[Chinese]` / `[English]` / `[Japanese]`）；
  翻译不会改动 `<d>` 块、`<Subject N>` / `<Picture N>` / `<Video N>` / `<Audio N>` 标签和时间码 `00:03.500`。
- **说话人必须写在 `<d>` 外面**：`<Subject 1> (S1) says, <d>[Chinese] 台词</d>`。
  `<d>` 里只允许出现 `[语种]` 和台词原文。把“谁说”“怎么说的”写进 `<d>` 里，
  H3 会把说话人标签一起念出来（实测 ASR 会转出“乞丐说”），多角色时还会认错说话人。
  导演台在生成前会自动改写（搬出标签、补 `[语种]`、去掉包裹引号、按 `subject_definitions` 映射到 `<Subject N> (Sx)`），
  但 Agent 直接写对更好。
- **镜外音 / 电话音 / 旁白也必须写出发声源**：电话那头、广播里、画外的声音不是画面里那个人在说。`<d>` 前面必须给出稳定的音色短语 + `(Sx)`，例如 `a serious male voice coming through the phone, with a steady natural timbre (S2) says: <d>[Chinese] 你名下经营的个体户是查账征收。</d>`；旁白用 `the off-screen narrator (S3): <d>…</d>`。漏写时 H3 会把这句台词派给画面里的人（实测：电话里的话变成画面人物自己在说）；同一通电话 / 同一个画外音跨镜必须用同一个 `(Sx)` 编号。导演台在生成前会按镜头上下文自动补齐缺失的发声源，但 Agent 直接写对更好。
- 没有配乐时 `non_diegetic_music: N/A`；不要写 “no background music” 这类否定句。

外置 Agent 写六段式的最小要求（放进 `POST /api/agent/v1/scripts/apply` 的 draft）：

```json
{
  "num": "1.1",
  "dur": 5,
  "assets": ["@张三", "@冷宫正殿"],
  "promptMode": "six",
  "h3PromptRaw": "subject_definitions:\n<Subject 1> is 张三 ...\ndetailed_description:\n[Shot 1] ...\nnon_diegetic_music:\nN/A"
}
```

导演台提供的六段式辅助接口（供 UI 与 Agent 了解能力，Agent 通常不需要调）：

- `GET /api/director/prompt/six/models`：列出可用翻译模型（不含明文 Key）。
- `POST /api/director/prompt/six/translate`：`{"text":"...","mode":"translate|polish","providerId":"","model":""}`
  返回 `{ok, en, notes, changes}`；中文 → 英文六段式，或英文 → 专业润色（`changes` 为中文改动说明）。
- `GET /api/director/script/template?format=six`：下载六段式 TXT 模板；`.txt` 可直接导入成剧本。


## 7. AI 配音（IndexTTS 2.5）

`POST /api/agent/v1/tts/generate` 请求体：

```json
{
  "text": "要合成的文本",
  "referenceAudioUrl": "/director_uploads/xxx.wav",
  "language": "ZH",
  "durationFactor": 1.0,
  "emotions": {"Happy": 0.0, "Angry": 0.0, "Sad": 0.0, "Fear": 0.0, "Hate": 0.0, "Love": 0.0, "Surprise": 0.0, "Neutral": 1.0},
  "seed": 0
}
```

- `language` 支持 `ZH / EN / JA / ES / AR`。
- `durationFactor` 语速：越大越快，`1.5` 即 1.5 倍速。
- `emotions` 八种情绪权重：Happy/Angry/Sad/Fear/Hate/Love/Surprise/Neutral，数值建议 0~1。
