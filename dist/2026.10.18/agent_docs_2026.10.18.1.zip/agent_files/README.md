# 墨川导演台 Agent 交付文件

本目录可独立分发给 Codex、OpenClaw、Claude Code、DeepSeek Harness 等 Agent，不依赖原始源码目录。

## 文件顺序

- `AGENTS.md`：入口与命名/模式澄清，先读。
- `SKILL.md`：稳定 Agent API、最小工作流、剧本 JSON 规范。
- `h3_skills\SKILL.md`：数据模型与 H3 官方提示词硬规则。
- `h3_skills\references\base-en.txt`：T2VA/I2VA/FL2VA/L2VA 格式。
- `h3_skills\references\ref-en.txt`：Ref2VA 六段式格式。

## 防截断提示

Agent 不应一次性把全部文件读入上下文。按需读取：写剧本读 `SKILL.md` 第 4 节；生成视频前再读 `h3_skills\SKILL.md` 第 6 节；只有需要改写 H3 提示词时才读 `references`。

## 负面提示

AI 编剧与 Agent 必须让 `negative` 保持空字符串 `""`。H3 没有负面词通道，禁止写“无字幕 / 无旁白 / 无背景音乐 / 不要 / 禁止”等否定短语。
## 模式（写分镜前必须先问用户）

剧本有 `promptMode`：`cards` 卡片式（默认，写 `shotCards`）/ `six` 六段式（用户直接写 H3 官方
六段提示词 `h3PromptRaw`）。外部 Agent 在写第一个分镜之前必须先问用户用哪种；用户没回答前不要写分镜。
两种模式的完整规范见 `h3_skills\SKILL.md` 第 6.2 节。

