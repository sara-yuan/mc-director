"""Latent-tail continuation with a schedule-matched prefix mask for MiniMax H3.

Carries the previous clip's sampled AV latent tail straight into the current
clip's opening and re-noises only that disposable video prefix, keeping the
seam-side latent clean. This is intentionally limited to the chained-clip
path (a previous sampled latent is wired); unrelated text-to-video and
reference pipelines never load this node.
"""

from __future__ import annotations

import math

import torch
from comfy.nested_tensor import NestedTensor
from comfy.patcher_extension import WrappersMP

FRAME_PER_TOKEN = (1, 4, 4, 4, 4)
FPS = 24.0
AUDIO_HZ = 40.0
TAPER_STEPS = 4
_WRAPPER_KEY = "h3_motion_context_drift_continuation"
_HARD_LOCK_MODE = "hard_lock"
_TAPER_MODE = "schedule_taper"


def _guide_frames(requested):
    """Align the requested overlap down to the H3 17g+5 frame grid."""
    requested = int(requested)
    if requested < 5:
        return 1
    while requested % 17 != 5:
        requested -= 1
    return max(1, requested)


def _video_tokens(frames):
    """Video latent steps that encode exactly ``frames`` pixel frames."""
    if frames <= 5:
        return 2
    return ((frames - 5) // 17) * 5 + 2


def _h3_streams(latent, label):
    """Unpack the video/audio pair of a MiniMax H3 AV latent.

    Accepts both the nested sampler output and the plain two-tensor list
    produced by MiniMaxH3MotionContextLoadLatent.
    """
    samples = latent.get("samples") if isinstance(latent, dict) else None
    if samples is None:
        raise ValueError(f"{label} must be a MiniMax H3 video-and-audio latent")
    if hasattr(samples, "is_nested") and samples.is_nested:
        tensors = list(getattr(samples, "tensors", ()))
    elif hasattr(samples, "unbind"):
        tensors = list(samples.unbind())
    elif isinstance(samples, (tuple, list)):
        tensors = list(samples)
    else:
        raise ValueError(f"{label} must be a MiniMax H3 video-and-audio latent")
    if len(tensors) != 2 or not torch.is_tensor(tensors[0]) or not torch.is_tensor(tensors[1]):
        raise ValueError(f"{label} is not a valid MiniMax H3 AV latent")
    if tensors[0].ndim != 5 or tensors[1].ndim != 4:
        raise ValueError(f"{label} is not a valid MiniMax H3 AV latent")
    return tensors[0], tensors[1]


def _sigma_values(sigmas):
    """Finite, non-negative schedule values in descending order."""
    if torch.is_tensor(sigmas):
        values = sigmas.detach().float().reshape(-1).cpu().tolist()
    else:
        values = list(sigmas or ())
    kept = sorted({float(v) for v in values if math.isfinite(float(v)) and float(v) >= 0.0}, reverse=True)
    return kept


def _matched_ratio(current, sigmas):
    """Portion of the prefix that stays live for this sampling step."""
    current = float(current)
    if not math.isfinite(current) or current <= 0.0:
        return 0.0
    tolerance = max(1e-7, abs(current) * 1e-6)
    for candidate in sigmas:
        if candidate < current - tolerance:
            return max(0.0, min(1.0, candidate / current))
    return 0.0


def _prefix_weights(steps, taper):
    """Weights for the carried prefix: full strength then a linear taper to 0."""
    steps = int(steps)
    taper = min(int(taper), steps)
    weights = [1.0] * (steps - taper)
    weights.extend(float(taper - offset - 1) / float(taper) for offset in range(taper))
    return weights


class _ContinuationState:
    def __init__(self, video_shape, audio_shape, prefix_steps):
        self.video_shape = tuple(int(v) for v in video_shape)
        self.audio_shape = tuple(int(v) for v in audio_shape)
        self.prefix_steps = int(prefix_steps)
        self.sigmas = []
        self.current_video_mask = None
        self.current_audio_mask = None

    def _update(self, sigma, packed_mask):
        current = float(torch.as_tensor(sigma).detach().float().reshape(-1)[0])
        ratio = _matched_ratio(current, self.sigmas)
        output = packed_mask.clone()
        video_elements = math.prod(self.video_shape[1:])
        video_mask = output[..., :video_elements].reshape(self.video_shape)
        weights = torch.tensor(
            _prefix_weights(self.prefix_steps, TAPER_STEPS),
            device=video_mask.device,
            dtype=torch.float32,
        ).mul_(ratio)
        video_mask[:, :, :self.prefix_steps, :, :] = weights.view(1, 1, -1, 1, 1)
        # Match the H3 token-mask quantization used by the sampler and model.
        self.current_video_mask = torch.ceil(video_mask[:, :1].float() * 256.0) / 256.0
        audio = output[..., video_elements:]
        self.current_audio_mask = audio.reshape(self.audio_shape)[:, :1].clone()
        return output

    def set_static_masks(self, latent):
        """Use the latent's static NestedTensor noise masks unchanged.

        ``noise_mask`` stores ``(video_mask, audio_mask)`` where video_mask is
        ``[1, 1, T, 1, 1]`` and audio_mask is ``[1, 1, 1, audio_len]``.  The
        sampler already uses the packed form to exactly replace the copied
        prefix with ``latent_image`` on every step; we only need these views so
        the H3 model can label the same rows with a zero timestep.
        """
        samples = latent.get("noise_mask") if isinstance(latent, dict) else None
        if samples is None:
            raise ValueError("Drift continuation requires a static video/audio noise mask")
        tensors = getattr(samples, "tensors", None)
        if tensors is None and hasattr(samples, "unbind"):
            tensors = list(samples.unbind())
        if not tensors or len(tensors) != 2:
            raise ValueError("Drift continuation requires a video/audio noise mask")
        self.current_video_mask = tensors[0]
        self.current_audio_mask = tensors[1]

    def denoise_mask_function(self, sigma, denoise_mask, extra_options=None):
        print("[DRIFT] denoise_mask_function sigma=%.4f packed=%s" % (float(sigma), tuple(denoise_mask.shape)), flush=True)
        if not self.sigmas:
            self.sigmas = _sigma_values((extra_options or {}).get("sigmas", ()))
        return self._update(sigma, denoise_mask)

    def apply_model_wrapper(self, executor, *args, **kwargs):
        print("[DRIFT] apply_model_wrapper video=%s audio=%s" % (None if self.current_video_mask is None else tuple(self.current_video_mask.shape), None if self.current_audio_mask is None else tuple(self.current_audio_mask.shape)), flush=True)
        if self.current_video_mask is not None:
            kwargs["denoise_mask"] = self.current_video_mask
        if self.current_audio_mask is not None:
            kwargs["audio_denoise_mask"] = self.current_audio_mask
        return executor(*args, **kwargs)


def _install_continuation_model(model, latent, prefix_steps, mode=_HARD_LOCK_MODE):
    if model is None or not callable(getattr(model, "clone", None)):
        raise ValueError("Drift continuation requires a ComfyUI MODEL input")
    inner = getattr(model, "model", None)
    model_type = str(getattr(getattr(inner, "model_type", None), "name", ""))
    if model_type != "FLOW_AV" and inner.__class__.__name__ != "MiniMaxH3":
        raise ValueError("Drift continuation requires a MiniMax H3 AV model")
    samples = latent.get("samples") if isinstance(latent, dict) else None
    if hasattr(samples, "unbind"):
        streams = list(samples.unbind())
    elif hasattr(samples, "tensors"):
        streams = list(samples.tensors)
    else:
        streams = []
    if len(streams) < 2 or not torch.is_tensor(streams[0]) or streams[0].ndim != 5:
        raise ValueError("Drift continuation requires a MiniMax H3 AV latent")
    prefix_steps = int(prefix_steps)
    if prefix_steps < 1 or prefix_steps >= int(streams[0].shape[2]):
        raise ValueError("The Drift continuation prefix must fit inside the target video latent")

    patched = model.clone()
    options = getattr(patched, "model_options", None)
    if not isinstance(options, dict):
        raise ValueError("The connected MODEL has no model_options dictionary")
    if mode not in (_HARD_LOCK_MODE, _TAPER_MODE):
        raise ValueError("Unknown Drift continuation mode: " + str(mode))
    if mode == _TAPER_MODE and callable(options.get("denoise_mask_function")):
        raise ValueError("Drift continuation cannot combine with another dynamic denoise-mask patch")
    if mode == _TAPER_MODE and not callable(getattr(patched, "set_model_denoise_mask_function", None)):
        raise RuntimeError("Drift continuation requires dynamic denoise-mask support")
    if not callable(getattr(patched, "add_wrapper_with_key", None)):
        raise RuntimeError("Drift continuation requires apply-model wrapper support")

    state = _ContinuationState(tuple(streams[0].shape), tuple(streams[1].shape), prefix_steps)
    if mode == _TAPER_MODE:
        patched.set_model_denoise_mask_function(state.denoise_mask_function)
    else:
        state.set_static_masks(latent)
    patched.add_wrapper_with_key(WrappersMP.APPLY_MODEL, _WRAPPER_KEY, state.apply_model_wrapper)
    return patched


class MiniMaxH3DriftContinuation:
    """Carry the previous sampled latent tail into the current clip and mask the seam.

    Wire the previous clip's sampler output to ``previous_latent`` and the current
    clip's empty latent to ``latent``. The node returns a patched model plus a
    masked latent whose carried prefix is re-noised on a schedule-matched taper,
    so the next clip genuinely continues the previous one without the Turbo
    sampler softening pinned keyframe rows.
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": ("MODEL",),
                "latent": ("LATENT",),
                "previous_latent": ("LATENT",),
                "overlap_frames": ("INT", {"default": 22, "min": 5, "max": 120}),
                "continue_audio": ("BOOLEAN", {"default": False}),
            },
            "optional": {
                "mode": (["hard_lock", "schedule_taper"], {"default": "hard_lock"}),
            },
        }

    RETURN_TYPES = ("MODEL", "LATENT", "INT")
    RETURN_NAMES = ("model", "latent", "trim_frames")
    FUNCTION = "apply"
    CATEGORY = "conditioning/minimax"
    DESCRIPTION = (
        "Latent-tail continuation with a schedule-matched prefix mask. Carries the "
        "previous sampled AV latent tail into the current opening and re-noises only "
        "that disposable video prefix, keeping the seam-side latent clean."
    )

    def apply(self, model, latent, previous_latent, overlap_frames=22, continue_audio=False, mode="hard_lock"):
        actual_frames = _guide_frames(int(overlap_frames))
        video_tokens = _video_tokens(actual_frames)

        target_video, target_audio = _h3_streams(latent, "latent")
        source_video, source_audio = _h3_streams(previous_latent, "previous_latent")

        if target_video.shape[3:] != source_video.shape[3:]:
            raise ValueError(
                "Drift continuation requires matching latent spatial dimensions; "
                f"got {tuple(source_video.shape[3:])} -> {tuple(target_video.shape[3:])}"
            )
        if video_tokens > source_video.shape[2] or video_tokens > target_video.shape[2]:
            raise ValueError(
                f"The source or target latent cannot hold a {actual_frames}-frame overlap "
                f"({video_tokens} video tokens required)"
            )

        video = target_video.clone()
        tail = source_video[:1, :, -video_tokens:, :, :].to(device=video.device, dtype=video.dtype)
        video[:, :, :video_tokens, :, :] = tail.expand(video.shape[0], -1, -1, -1, -1)

        # Static noise mask: the carried prefix starts as preserved (0) and the
        # dynamic denoise-mask function drives its per-step taper; everything
        # after the prefix is fully denoised (1).
        video_mask = torch.ones(
            (1, 1, target_video.shape[2], 1, 1),
            dtype=torch.float32,
            device=target_video.device,
        )
        video_mask[:, :, :video_tokens, :, :] = 0.0

        audio = target_audio.clone()
        audio_mask = torch.ones(
            (1, 1, 1, target_audio.shape[-1]),
            dtype=torch.float32,
            device=target_audio.device,
        )
        if bool(continue_audio):
            audio_tokens = min(
                round(actual_frames * AUDIO_HZ / FPS),
                source_audio.shape[-1],
                target_audio.shape[-1],
            )
            if audio_tokens < 1:
                raise ValueError("The source or target H3 audio latent is too short for audio overlap")
            audio_tail = source_audio[:1, :, :, -audio_tokens:].to(device=audio.device, dtype=audio.dtype)
            audio[..., :audio_tokens] = audio_tail.expand(audio.shape[0], -1, -1, -1)
            audio_mask[..., :audio_tokens] = 0.0

        output = dict(latent)
        output["samples"] = NestedTensor((video, audio))
        output["noise_mask"] = NestedTensor((video_mask, audio_mask))

        print("[DRIFT] apply overlap=%d video_tokens=%d video=%s audio=%s" % (actual_frames, video_tokens, tuple(video.shape), tuple(audio.shape)), flush=True)
        patched = _install_continuation_model(model, output, video_tokens, mode)
        return (patched, output, actual_frames)


NODE_CLASS_MAPPINGS = {
    "MiniMaxH3DriftContinuation": MiniMaxH3DriftContinuation,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "MiniMaxH3DriftContinuation": "MiniMax H3 Drift Continuation",
}


