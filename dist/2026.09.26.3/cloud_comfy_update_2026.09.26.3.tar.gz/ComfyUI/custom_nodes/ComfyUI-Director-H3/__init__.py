import inspect
import nodes
import node_helpers
import torch
from comfy_api.latest import io
from comfy_extras.nodes_minimax_h3 import (
    MiniMaxH3ReferenceToVideo,
    _resize,
    temporal_shape,
)

MC_KEY = "motion_context_index"


def _filter_dit_ref_images(cond, ref_images, ref_dit_images):
    """按 ref_dit_images 过滤 DiT 视觉参考行（Qwen 语义参考不受影响）。

    ""      -> 不过滤（旧行为）
    "none"  -> 一张都不进 DiT，只保留 Qwen 语义参考
    "0,2"   -> 只让这些下标的参考图进 DiT
    参考图行永远排在最前面，其后才是参考视频/参考音频行，按下标过滤即可。
    """
    raw = str(ref_dit_images or "").strip().lower()
    if not raw:
        return cond
    keep = set()
    if raw != "none":
        for part in raw.split(","):
            part = part.strip()
            if part.lstrip("-").isdigit():
                keep.add(int(part))
    n_images = len([v for v in (ref_images or {}).values() if v is not None])
    out = []
    for entry in cond:
        if not isinstance(entry, (list, tuple)) or len(entry) < 2 or not isinstance(entry[1], dict):
            out.append(entry)
            continue
        refs = entry[1].get("minimax_refs")
        if not refs:
            out.append(entry)
            continue
        kept = []
        for i, block in enumerate(refs):
            if (i < n_images and isinstance(block, dict) and block.get("kind") == "image"
                    and i not in keep):
                continue
            kept.append(block)
        meta = dict(entry[1])
        if kept:
            meta["minimax_refs"] = kept
        else:
            meta.pop("minimax_refs", None)
            meta.pop("minimax_visual_cond_noise_aug", None)
        out.append([entry[0], meta])
    return out

def _video_block_as_audio(block):
    """把参考视频块降级为「纯音频参考块」。

    DiT 的画面参考行里，一个参考视频块会占 latent_t 乘 空间格 行：
    一条 13 秒的参考视频约 92 帧画面参考，而单张参考图只占 1 帧。
    所以「参考图 + 参考视频」同时出现时，参考视频会把参考图彻底压掉，
    表现为换人与换场景失败、画面直接照抄参考视频。
    这里只保留它的音频参考行（背景音乐与原声仍然生效），
    画面信息改由 Qwen 多模语义通道承担。
    """
    return {
        "kind": "audio",
        "ref_audio_t": int(block.get("ref_audio_t") or 0),
        "audio_latent": block.get("audio_latent"),
    }


def _subsample_dit_video_frames(cond, n):
    """把参考视频块抽稀成 n 个等间隔关键帧，仍保留 video 块与音轨。

    参考视频满帧（13 秒约 92 帧）会把原视频人物像素整段钉进 DiT，导致成片
    “一闪一闪回到原人物”。抽稀后只保留动作轨迹锚点，原人物像素大幅减少，
    同时 DiT 仍有一个按时间排列的动作锚，而不是只剩 Qwen 的 2fps 语义。
    """
    out = []
    for entry in cond:
        if not isinstance(entry, (list, tuple)) or len(entry) < 2 or not isinstance(entry[1], dict):
            out.append(entry)
            continue
        refs = entry[1].get("minimax_refs")
        if not refs:
            out.append(entry)
            continue
        kept = []
        for block in refs:
            if isinstance(block, dict) and block.get("kind") in ("video", "video_audio"):
                z = block.get("latent")
                t = int(block.get("latent_t") or 0)
                if z is not None and t > n:
                    idx = torch.linspace(0, t - 1, n).round().long().unique()
                    zb = dict(block)
                    zb["latent"] = z[..., idx, :, :]
                    zb["latent_t"] = int(idx.numel())
                    kept.append(zb)
                    continue
            kept.append(block)
        meta = dict(entry[1])
        if kept:
            meta["minimax_refs"] = kept
        else:
            meta.pop("minimax_refs", None)
            meta.pop("minimax_visual_cond_noise_aug", None)
        out.append([entry[0], meta])
    return out


def _filter_dit_ref_videos(cond, ref_images, ref_videos, ref_dit_videos):
    """按 ref_dit_videos 决定参考视频是否占用 DiT 画面参考行。

    auto 为默认：同一分镜里既有参考图又有参考视频时，参考视频只当动作与音频参考；
    all 为旧行为（整段进画面参考行）；none 为总是只当动作与音频参考；
    key:N 为抽稀模式：参考视频只留 N 个等间隔关键帧进 DiT（音轨保留）。
    """
    has_videos = any(v is not None for v in (ref_videos or {}).values())
    if not has_videos:
        return cond
    raw = str(ref_dit_videos or "").strip().lower()
    if raw.startswith("key:"):
        try:
            key_frames = max(1, int(raw[4:]))
        except ValueError:
            return cond
        return _subsample_dit_video_frames(cond, key_frames)
    if raw in ("all", "keep", "1"):
        return cond
    if raw == "none":
        drop = True
    else:
        drop = any(v is not None for v in (ref_images or {}).values())
    if not drop:
        return cond
    out = []
    for entry in cond:
        if not isinstance(entry, (list, tuple)) or len(entry) < 2 or not isinstance(entry[1], dict):
            out.append(entry)
            continue
        refs = entry[1].get("minimax_refs")
        if not refs:
            out.append(entry)
            continue
        kept = []
        for block in refs:
            if isinstance(block, dict) and block.get("kind") in ("video", "video_audio"):
                if int(block.get("ref_audio_t") or 0) > 0:
                    kept.append(_video_block_as_audio(block))
                continue
            kept.append(block)
        meta = dict(entry[1])
        if kept:
            meta["minimax_refs"] = kept
        else:
            meta.pop("minimax_refs", None)
            meta.pop("minimax_visual_cond_noise_aug", None)
        out.append([entry[0], meta])
    return out

def _parent_execute_kwargs(kwargs):
    """只把父类真正支持的参数传下去。

    本地与云端（以及不同用户）的 ComfyUI 内核版本不一致：
    旧内核没有 ref_images_label_only 等新参数，直接传下去会 TypeError 导致整条生成链路失败。
    这里按父类签名过滤一遍，旧内核自动只传它认识的参数。
    """
    try:
        params = inspect.signature(MiniMaxH3ReferenceToVideo.execute).parameters
    except (TypeError, ValueError):
        params = None
    if params:
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in params.values()):
            return dict(kwargs)
        return {k: v for k, v in kwargs.items() if k in params}
    return {k: v for k, v in kwargs.items() if k != "ref_images_label_only"}


def _exec_parent(kwargs):
    """参数过滤后调父类；万一仍然碰到不认识的关键字参数，自动剔除后重试。"""
    kwargs = _parent_execute_kwargs(kwargs)
    for _ in range(4):
        try:
            return MiniMaxH3ReferenceToVideo.execute(**kwargs)
        except TypeError as exc:
            msg = str(exc)
            if "unexpected keyword argument" not in msg:
                raise
            name = msg.split("unexpected keyword argument", 1)[1].strip().strip("'\"")
            if name not in kwargs:
                raise
            kwargs.pop(name)
    raise TypeError("MiniMaxH3DirectorToVideo: 父类参数不兼容")

class MiniMaxH3DirectorToVideo(MiniMaxH3ReferenceToVideo):
    """导演台专用 conditioning：参考图/参考视频/参考音频 + 首尾关键帧。

    自动行为：同一分镜同时传了参考图与参考视频时，参考视频不再占 DiT 画面参考行
    （仅保留其音频参考），避免整段参考视频把参考图的人物与场景彻底压掉。

    兼容 MiniMaxH3ReferenceToVideo 的所有参考输入，同时增加 first_frame 与
    last_frame。这样下一分镜既能把资产参考全部传给 H3，又能用上一分镜尾帧
    锁定本镜第一帧，避免远景/连续镜头人物糊脸或衣着漂移。
    """

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3DirectorToVideo",
            display_name="MiniMax H3 Director (Refs + Keyframes)",
            category="model/conditioning/minimax",
            description="导演台专用：参考图 + 参考视频 + 参考音频 + 首尾关键帧合并 conditioning。",
            inputs=[
                io.Clip.Input("clip"),
                io.Vae.Input("vae"),
                io.Vae.Input("audio_vae"),
                io.String.Input("prompt", multiline=True, dynamic_prompts=True),
                io.Int.Input("width", default=1344, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("height", default=768, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("length", default=124, min=5, max=3600, step=17),
                io.Combo.Input("ref_image_size", options=["match", "max"], default="max",
                    tooltip="参考图尺寸。max=保持参考图清晰度（推荐，实测最干净）；match=把每张参考图缩到目标画面尺寸，参考图维度与输出帧一致时 H3 更容易把参考图当成开场帧渲染。"),
                io.Float.Input("ref_visual_noise_aug", default=0.999, min=0.0, max=1.0, step=0.001, advanced=True,
                    tooltip="Visual condition noise augmentation. 官方权重按 0.999 训练；低于 0.999（例如 0.985）相当于半噪声参考图，H3 会把它当画面渲染成开场帧。0 表示关闭 DiT 视觉参考行。"),
                io.String.Input("ref_images_qwen_skip", default=""),
                io.String.Input("ref_images_label_only", default="none",
                    tooltip="哪些参考图只发文字标签、不发视觉块。none=全部发视觉块（官方默认：参考图同时进 Qwen 视觉块与 DiT 视觉参考行）；空=全部只发标签；0,2=只有这些下标只发标签。"),
                io.String.Input("ref_dit_images", default="", optional=True,
                    tooltip="哪些参考图允许进入 DiT 视觉参考行（会被当成画面内容渲染，常见现象：参考图被画成开场首帧、三视图入画）。空=全部进（旧行为）；none=全部不进，只走 Qwen 语义参考；0,2=只让这些下标的参考图进 DiT。"),
                io.String.Input("ref_dit_videos", default="auto", optional=True,
                    tooltip="参考视频是否占用 DiT 画面参考行。auto=同一分镜里既有参考图又有参考视频时，参考视频只当动作与音频参考，不再抢画面；all=旧行为；none=总是只当动作参考。"),
                io.Autogrow.Input("ref_images", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Image.Input("ref_image"),
                        prefix="ref_image_", min=0, max=9)),
                io.Autogrow.Input("ref_videos", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Image.Input("ref_video"),
                        prefix="ref_video_", min=0, max=3)),
                io.Autogrow.Input("ref_video_audios", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Audio.Input("ref_video_audio"),
                        prefix="ref_video_audio_", min=0, max=3)),
                io.Autogrow.Input("ref_audios", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Audio.Input("ref_audio"),
                        prefix="ref_audio_", min=0, max=3)),
                io.Image.Input("first_frame", optional=True),
                io.Image.Input("last_frame", optional=True),
            ],
            outputs=[io.Conditioning.Output(display_name="positive"), io.Latent.Output()],
        )

    @classmethod
    def execute(cls, clip, vae, audio_vae, prompt, width, height, length,
                ref_image_size="max", ref_visual_noise_aug=0.999, ref_images=None, ref_videos=None,
                ref_video_audios=None, ref_audios=None, ref_images_qwen_skip="", ref_dit_images="",
                ref_dit_videos="auto",
                ref_images_label_only="none", first_frame=None,
                last_frame=None):
        cond, latent = _exec_parent({
            "clip": clip,
            "vae": vae,
            "audio_vae": audio_vae,
            "prompt": prompt,
            "width": width,
            "height": height,
            "length": length,
            "ref_image_size": ref_image_size,
            "ref_visual_noise_aug": ref_visual_noise_aug,
            "ref_images": ref_images,
            "ref_images_qwen_skip": ref_images_qwen_skip,
            "ref_images_label_only": ref_images_label_only,
            "ref_videos": ref_videos,
            "ref_video_audios": ref_video_audios,
            "ref_audios": ref_audios,
        })

        cond = _filter_dit_ref_images(cond, ref_images, ref_dit_images)
        cond = _filter_dit_ref_videos(cond, ref_images, ref_videos, ref_dit_videos)

        frame_count, _, _ = temporal_shape(length)
        keyframes = []
        if first_frame is not None:
            img = _resize(first_frame[:1], width, height, "disabled")
            keyframes.append({"resolved_frame_index": 0, MC_KEY: 0, "image": img})
        if last_frame is not None:
            img = _resize(last_frame[:1], width, height, "center")
            keyframes.append({"resolved_frame_index": frame_count - 1, MC_KEY: frame_count - 1, "image": img})
        if keyframes:
            for kf in keyframes:
                kf["latent"] = vae.encode(kf.pop("image"))
            cond = node_helpers.conditioning_set_values(cond, {
                "minimax_keyframes": keyframes,
                "minimax_frame_count": frame_count,
            })
        return io.NodeOutput(cond, latent)


NODE_CLASS_MAPPINGS = {
    "MiniMaxH3DirectorToVideo": MiniMaxH3DirectorToVideo,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "MiniMaxH3DirectorToVideo": "MiniMax H3 Director (Refs + Keyframes)",
}
