"""MiniMax H3 nodes: AV latent creation and task conditioning (t2va / fl2va / ref2va).

The H3 packed-DiT consumes, via conditioning:
- Qwen3-VL-32B hidden states with per-token modality tags (from the minimax CLIP)
- keyframe / reference condition latents, re-injected every step (never denoised)

Latents are NestedTensor pairs (video [B,24,T,H/16,W/16], audio [B,32,2,T40]);
sampling runs on the flat pack with any stock sampler (the model handles the
audio stream's shifted schedule internally).
"""

import math

import torch
import torch.nn.functional as F
import torchaudio

import nodes
import comfy.model_management
import comfy.model_prefetch
import comfy.model_sampling
import comfy.nested_tensor
import comfy.patcher_extension
import comfy.utils
import node_helpers
from comfy.ldm.minimax.vae import IMAGENET_MEAN
from comfy_api.latest import ComfyExtension, io

# Fun ControlNet backport: newer ComfyUI pauses malloc-graph tracking around control
# weight staging. This 0.30 kernel has no malloc graph, so it degrades to a no-op.
if not hasattr(comfy.model_prefetch, "pause_malloc_graph"):
    import contextlib

    @contextlib.contextmanager
    def _pause_malloc_graph():
        yield

    comfy.model_prefetch.pause_malloc_graph = _pause_malloc_graph

CANVAS_MULTIPLE = 32
BASE_SHORT_EDGE = 768
MAX_PIXELS = 768 * 1344
REF_IMAGE_SHORT_EDGE = 2048
FPS = 24
AUDIO_LATENT_FPS = 40


def align_frame_count(n):
    while n % 17 != 5:
        n += 1
    return n


def video_latent_t(frame_count):
    return 2 if frame_count <= 5 else ((frame_count - 5) // 17) * 5 + 2


def temporal_shape(length):
    frame_count = align_frame_count(max(5, length))
    duration = frame_count / FPS
    return frame_count, video_latent_t(frame_count), round(duration * AUDIO_LATENT_FPS)


def adapt_canvas(width, height):
    """768-short-edge canvas with 768*1344 area cap, per-axis round to 32."""
    ratio = width / height
    if ratio >= 1.0:
        nom_w, nom_h = BASE_SHORT_EDGE * ratio, BASE_SHORT_EDGE
    else:
        nom_w, nom_h = BASE_SHORT_EDGE, BASE_SHORT_EDGE / ratio
    if nom_w * nom_h > MAX_PIXELS:
        s = math.sqrt(MAX_PIXELS / (nom_w * nom_h))
        nom_w, nom_h = nom_w * s, nom_h * s
    return (max(CANVAS_MULTIPLE, round(nom_w / CANVAS_MULTIPLE) * CANVAS_MULTIPLE),
            max(CANVAS_MULTIPLE, round(nom_h / CANVAS_MULTIPLE) * CANVAS_MULTIPLE))


def _resize(image, width, height, crop):
    # image [B, H, W, C] -> [B, height, width, 3]
    samples = image[..., :3].movedim(-1, 1)
    samples = comfy.utils.common_upscale(samples, width, height, "lanczos", crop)
    return samples.movedim(1, -1)


def _empty_av_latent(width, height, length, batch_size=1):
    frame_count, latent_t, audio_t = temporal_shape(length)
    video = torch.zeros([batch_size, 24, latent_t, height // 16, width // 16],
                        device=comfy.model_management.intermediate_device())
    audio = torch.zeros([batch_size, 32, 2, audio_t],
                        device=comfy.model_management.intermediate_device())
    return {"samples": comfy.nested_tensor.NestedTensor((video, audio))}, frame_count


class EmptyMiniMaxH3LatentAV(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="EmptyMiniMaxH3LatentAV",
            display_name="Empty MiniMax H3 AV Latent",
            category="model/latent/minimax",
            description="Joint video+audio latent for MiniMax H3. Duration snaps to the model's 17k+5 frame grid at 24 fps.",
            inputs=[
                io.Int.Input("width", default=1344, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("height", default=768, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("length", default=124, min=5, max=3600, step=17, tooltip="Frame count at 24 fps, snapped up to the model's 17k+5 grid (124 = ~5s; trained range is ~124-362, longer is untested)"),
            ],
            outputs=[io.Latent.Output()],
        )

    @classmethod
    def execute(cls, width, height, length) -> io.NodeOutput:
        latent, _ = _empty_av_latent(width, height, length)
        return io.NodeOutput(latent)


class MiniMaxH3ImageToVideo(io.ComfyNode):
    """t2va and fl2va: prompt (+ optional first/last keyframes) -> conditioning + AV latent."""

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3ImageToVideo",
            display_name="MiniMax H3 Image to Video",
            category="model/conditioning/minimax",
            inputs=[
                io.Clip.Input("clip"),
                io.Vae.Input("vae"),
                io.String.Input("prompt", multiline=True, dynamic_prompts=True),
                io.Int.Input("width", default=1344, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("height", default=768, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("length", default=124, min=5, max=3600, step=17, tooltip="Frame count at 24 fps, snapped up to the model's 17k+5 grid (124 = ~5s; trained range is ~124-362, longer is untested)"),
                io.Image.Input("first_frame", optional=True),
                io.Image.Input("last_frame", optional=True),
            ],
            outputs=[io.Conditioning.Output(display_name="positive"), io.Latent.Output()],
        )

    @classmethod
    def execute(cls, clip, vae, prompt, width, height, length,
                first_frame=None, last_frame=None) -> io.NodeOutput:
        latent, frame_count = _empty_av_latent(width, height, length)

        images = []
        keyframes = []
        if first_frame is not None:
            # geometry anchor: plain stretch to canvas
            img = _resize(first_frame[:1], width, height, "disabled")
            images.append(img)
            keyframes.append({"resolved_frame_index": 0, "image": img})
        if last_frame is not None:
            # follower: aspect-preserving cover-crop
            img = _resize(last_frame[:1], width, height, "center")
            images.append(img)
            keyframes.append({"resolved_frame_index": frame_count - 1, "image": img})

        tokens = clip.tokenize(prompt, images=images)
        cond = clip.encode_from_tokens_scheduled(tokens)

        if keyframes:
            for kf in keyframes:
                kf["latent"] = vae.encode(kf.pop("image"))
            cond = node_helpers.conditioning_set_values(cond, {
                "minimax_keyframes": keyframes,
                "minimax_frame_count": frame_count,
            })
        return io.NodeOutput(cond, latent)


class MiniMaxH3ReferenceToVideo(io.ComfyNode):
    """ref2va: prompt + reference images / videos / audio -> conditioning + AV latent.

    References enter the presentation in fixed order: images, then videos (each
    soundtrack's <Audio j> label right before its <Video k>), then standalone
    audio. Ordinals are 1-based per type, so the prompt refers to them as
    <Picture i> / <Video k> / <Audio j>.
    """

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3ReferenceToVideo",
            description="<Picture i> / <Video k> / <Audio j> reference conditioning for MiniMax H3. Use the same tags when prompting.",
            display_name="MiniMax H3 Reference to Video",
            category="model/conditioning/minimax",
            inputs=[
                io.Clip.Input("clip"),
                io.Vae.Input("vae"),
                io.Vae.Input("audio_vae"),
                io.String.Input("prompt", multiline=True, dynamic_prompts=True),
                io.Int.Input("width", default=1344, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("height", default=768, min=32, max=nodes.MAX_RESOLUTION, step=32),
                io.Int.Input("length", default=124, min=5, max=3600, step=17, tooltip="Frame count at 24 fps, (124 = ~5s, trained range is ~124-362)"),
                io.Combo.Input("ref_image_size", options=["match", "max"], default="match",
                    tooltip="Reference image sizing. 'match' scales each ref (down only, keeping aspect) to the generation's pixel area; 'max' uses the reference pipeline's 2048px short edge for best identity fidelity. Reference tokens ride through every sampling step, so 'max' can be several times slower."),
                io.Float.Input("ref_visual_noise_aug", default=0.999, min=0.0, max=1.0, step=0.001, advanced=True,
                    tooltip="Visual condition noise augmentation for pure multi-reference mode. 0 disables DiT visual reference rows and keeps only the Qwen multimodal reference, which prevents reference sheets from being rendered as opening frames. Values above 0 blend DiT reference latents with noise at this timestep. Stock is 0.999."),
                io.String.Input("ref_images_qwen_skip", default=""),
                io.String.Input("ref_images_label_only", default="none",
                    tooltip="哪些参考图只发文字标签、不发视觉块。none=全部发视觉块（官方默认：参考图同时进 Qwen 视觉块与 DiT 视觉参考行）；空=全部只发标签；0,2=只有这些下标只发标签。"),
                io.Autogrow.Input("ref_images", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Image.Input("ref_image", tooltip="Reference image (downscaled to 2048 short edge if larger, never upscaled)"),
                        prefix="ref_image_", min=0, max=9)),
                io.Autogrow.Input("ref_videos", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Image.Input("ref_video", tooltip="Reference video frames at 24 fps (2-15s)"),
                        prefix="ref_video_", min=0, max=3)),
                io.Autogrow.Input("ref_video_audios", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Audio.Input("ref_video_audio", tooltip="Soundtrack of the same-numbered reference video"),
                        prefix="ref_video_audio_", min=0, max=3)),
                io.Autogrow.Input("ref_audios", optional=True,
                    template=io.Autogrow.TemplatePrefix(
                        input=io.Audio.Input("ref_audio", tooltip="Standalone reference audio"),
                        prefix="ref_audio_", min=0, max=3)),
            ],
            outputs=[io.Conditioning.Output(display_name="positive"), io.Latent.Output()],
        )

    @staticmethod
    def _encode_ref_audio(audio_vae, audio):
        waveform = audio["waveform"]  # 通常为 [B, C, L]（声道在前）
        sr = audio["sample_rate"]
        vae_sr = getattr(audio_vae, "audio_sample_rate", 32000)
        if sr != vae_sr:
            waveform = torchaudio.functional.resample(waveform, sr, vae_sr)
        # MiniMax 音频 VAE encode 需要 [B, C, L]；LoadAudio / GetVideoComponents
        # 输出即为该布局。若上游是 [B, L, C]（时间在前，如某些解码节点），转回声道在前。
        if waveform.ndim == 3 and waveform.shape[1] > 4 and waveform.shape[2] <= 4:
            waveform = waveform.movedim(1, 2)
        z = audio_vae.encode(waveform[:1].movedim(1, -1))  # comfy.sd.VAE wrapper expects [B, L, C]（时间在前），内部转 [B, C, L]
        return z, z.shape[-1]

    @classmethod
    def execute(cls, clip, vae, audio_vae, prompt, width, height, length, ref_image_size="match",
                ref_visual_noise_aug=0.999, ref_images=None, ref_videos=None, ref_video_audios=None, ref_audios=None,
                ref_images_qwen_skip="", ref_images_label_only="none") -> io.NodeOutput:
        latent, frame_count = _empty_av_latent(width, height, length)

        ref_items = []   # for the tokenizer presentation, in request order
        ref_blocks = []  # for the DiT payload, same order

        skip_qwen = set(int(x.strip()) for x in (ref_images_qwen_skip or "").split(",") if x.strip().isdigit())
        use_split_qwen = bool(skip_qwen)
        # 参考图默认只给 Qwen 一个 "<Picture i>: " 文字标签，不发视觉块：
        # 视觉块（带 video 模态标记的图像 embedding）会被 H3 直接当画面内容渲染，
        # 典型现象就是"开场闪过参考图/场景图当首帧/多张参考图拼贴"。参考像素只走
        # DiT 视觉参考行，身份与场景依旧锁得住，但不会被画成帧。
        label_only_raw = str(ref_images_label_only or "").strip().lower()
        if label_only_raw == "none":
            label_only_all = False
            label_only = set()
        elif label_only_raw:
            label_only_all = False
            label_only = set(int(x.strip()) for x in label_only_raw.replace(" ", ",").split(",")
                             if x.strip().lstrip("-").isdigit())
        else:
            label_only_all = True
            label_only = set()
        for idx, img in enumerate((ref_images or {}).values()):
            if img is None:
                continue
            qwen_skip = idx in skip_qwen
            h, w = img.shape[1], img.shape[2]
            if ref_image_size == "match":
                # aspect-preserving scale (down only) to the generation's pixel area
                scale = min(1.0, math.sqrt((width * height) / (w * h)))
            else:
                scale = min(1.0, REF_IMAGE_SHORT_EDGE / min(w, h))
            tw = max(CANVAS_MULTIPLE, round(w * scale / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
            th = max(CANVAS_MULTIPLE, round(h * scale / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
            resized = _resize(img[:1], tw, th, "disabled")
            z = vae.encode(resized)
            if not qwen_skip:
                if label_only_all or idx in label_only:
                    ref_items.append({"type": "image_text"})
                else:
                    ref_items.append({"type": "image", "data": resized})
            if use_split_qwen and qwen_skip:
                ref_blocks.append({"kind": "image", "latent_h": th // 16, "latent_w": tw // 16, "latent": z})
            elif not use_split_qwen:
                ref_blocks.append({"kind": "image", "latent_h": th // 16, "latent_w": tw // 16, "latent": z})

        ref_video_audios = ref_video_audios or {}
        for name, video_frames in (ref_videos or {}).items():
            if video_frames is None:
                continue
            # index-paired soundtrack: ref_video_audio_N belongs to ref_video_N
            soundtrack = ref_video_audios.get("ref_video_audio_" + name.rsplit("_", 1)[-1])
            vh, vw = video_frames.shape[1], video_frames.shape[2]
            cw, ch = adapt_canvas(vw, vh)
            if vw * vh < cw * ch:
                cw = max(CANVAS_MULTIPLE, round(vw / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
                ch = max(CANVAS_MULTIPLE, round(vh / CANVAS_MULTIPLE) * CANVAS_MULTIPLE)
            frames = _resize(video_frames, cw, ch, "disabled")
            if frames.shape[0] > frame_count:
                frames = frames[:frame_count]
            n = frames.shape[0]
            if n < 5:
                raise ValueError("MiniMax H3 reference videos need at least 5 frames (~0.2s at 24 fps)")
            while n % 17 != 5:
                n -= 1
            frames = frames[:n]
            z = vae.encode(frames)
            audio_latent, ref_audio_t = (None, 0)
            if soundtrack is not None:
                audio_latent, ref_audio_t = cls._encode_ref_audio(audio_vae, soundtrack)
                # the soundtrack gets its own <Audio j> label, emitted before <Video k>
                ref_items.append({"type": "audio"})
            # Qwen sees the video at 2 fps with timestamps
            sample_idx = list(range(0, frames.shape[0], FPS // 2))
            qwen_frames = frames[sample_idx]
            ref_items.append({"type": "video", "data": qwen_frames,
                              "timestamps": [i / 2.0 for i in range(len(sample_idx))]})
            ref_blocks.append({"kind": "video_audio" if ref_audio_t else "video",
                               "latent_t": z.shape[2], "latent_h": ch // 16, "latent_w": cw // 16,
                               "ref_audio_t": ref_audio_t, "latent": z, "audio_latent": audio_latent})

        for audio in (ref_audios or {}).values():
            if audio is None:
                continue
            audio_latent, ref_audio_t = cls._encode_ref_audio(audio_vae, audio)
            ref_items.append({"type": "audio"})
            ref_blocks.append({"kind": "audio", "ref_audio_t": ref_audio_t, "audio_latent": audio_latent})

        tokens = clip.tokenize(prompt, minimax_ref_items=ref_items)
        cond = clip.encode_from_tokens_scheduled(tokens)
        if ref_blocks and float(ref_visual_noise_aug) > 0.0:
            cond = node_helpers.conditioning_set_values(cond, {
                "minimax_refs": ref_blocks,
                "minimax_visual_cond_noise_aug": max(0.0, min(1.0, float(ref_visual_noise_aug))),
            })
        return io.NodeOutput(cond, latent)


class MiniMaxH3SigmaShift(io.ComfyNode):
    """Set the video/audio flow shifts coherently.

    The video shift drives the sampler's sigma schedule (ModelSamplingAV); both
    values are also handed to the DiT, which inverts the video schedule to the
    shared base grid and derives the audio schedule from it.
    """

    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3SigmaShift",
            description="Set the video/audio flow shifts.",
            display_name="ModelSamplingMiniMaxH3",
            search_aliases=["sigma shift", "minimax shift"],
            category="model/patch/minimax",
            inputs=[
                io.Model.Input("model"),
                io.Float.Input("shift_video", default=12.0, min=0.01, max=100.0, step=0.01),
                io.Float.Input("shift_audio", default=3.0, min=0.01, max=100.0, step=0.01),
            ],
            outputs=[io.Model.Output()],
        )

    @classmethod
    def execute(cls, model, shift_video, shift_audio) -> io.NodeOutput:
        m = model.clone()

        class ModelSamplingAdvanced(comfy.model_sampling.ModelSamplingAV, comfy.model_sampling.CONST):
            pass

        original = m.get_model_object("model_sampling")
        model_sampling = ModelSamplingAdvanced(model.model.model_config)
        model_sampling.set_parameters(shift=shift_video, audio_shift=shift_audio)
        if hasattr(original, "noise_scale"):
            model_sampling.set_noise_scale(original.noise_scale)
        m.add_object_patch("model_sampling", model_sampling)

        to = m.model_options["transformer_options"] = m.model_options.get("transformer_options", {}).copy()
        to["minimax_h3_sigma_shift_video"] = shift_video
        to["minimax_h3_sigma_shift_audio"] = shift_audio
        return io.NodeOutput(m)


class MiniMaxH3FunControlPatch:
    def __init__(self, model_patch, vae, control_video, mask, source_video, strength, sigma_start, sigma_end):
        self.model_patch = model_patch
        self.vae = vae
        self.control_video = control_video
        self.mask = mask
        self.source_video = source_video
        self.strength = strength
        self.sigma_start = sigma_start
        self.sigma_end = sigma_end
        self.control_latent = None
        self.control_latent_shape = None
        self.control_stream = None
        self.pristine_stream = None
        self.active = False

    def _fit_frames(self, frames, frame_count, width, height):
        indices = torch.arange(frame_count, device=frames.device).clamp(max=frames.shape[0] - 1)
        return comfy.utils.common_upscale(frames[indices], width, height, "bilinear", "center")

    def _encode(self, frames, target_shape):
        latent = self.vae.encode(frames.movedim(1, -1)).to(torch.float32)
        if tuple(latent.shape) != target_shape:
            raise ValueError("MiniMax H3 Fun VAE output shape {} does not match the target {}".format(tuple(latent.shape), target_shape))
        return latent

    def prepare_control_latent(self, target_shape):
        target_shape = tuple(target_shape)
        if self.control_latent is not None and self.control_latent_shape == target_shape:
            return

        latent_frames, latent_height, latent_width = target_shape[2:]
        frame_count = max((latent_frames - 2) // 5, 0) * 17 + 5
        spatial_compression = self.vae.spacial_compression_encode()
        width = latent_width * spatial_compression
        height = latent_height * spatial_compression
        loaded_models = comfy.model_management.loaded_models(only_currently_used=True)

        try:
            hint = None
            if self.control_video is not None:
                frames = self._fit_frames(self.control_video, frame_count, width, height)
                hint = self._encode(frames, target_shape)

            if self.mask is not None:
                mask = (self.mask.reshape(-1, 1, self.mask.shape[-2], self.mask.shape[-1]) > 0.5).to(torch.float32)
                indices = torch.arange(frame_count, device=mask.device).clamp(max=mask.shape[0] - 1)
                mask = comfy.utils.common_upscale(mask[indices], width, height, "bilinear", "center")
                visibility = 1.0 - (mask > 0.5).to(torch.float32)
                if self.source_video is None:
                    source = torch.zeros(frame_count, 3, height, width, dtype=visibility.dtype, device=visibility.device)
                else:
                    source = self._fit_frames(self.source_video, frame_count, width, height)
                visibility = visibility.to(source.device)
                masked = source * visibility
                if self.model_patch.model.inpaint_post_norm:
                    masked += (1.0 - visibility) * torch.tensor(IMAGENET_MEAN, dtype=source.dtype, device=source.device).view(1, 3, 1, 1)
                masked_latent = self._encode(masked, target_shape)
                if hint is None:
                    hint = torch.zeros_like(masked_latent)
                visibility_latent = F.interpolate(
                    visibility.squeeze(1)[None, None], size=(latent_frames, latent_height, latent_width),
                    mode="trilinear", align_corners=False)
                hint = torch.cat([hint, visibility_latent.to(hint.device), masked_latent.to(hint.device)], dim=1)
        finally:
            comfy.model_management.load_models_gpu(loaded_models)

        self.control_latent = hint
        self.control_latent_shape = target_shape

    def diffusion_model_wrapper(self, executor, x, timestep, context, transformer_options={}, **kwargs):
        sigmas = transformer_options.get("sigmas")
        sigma = float(sigmas[0]) if sigmas is not None else float(timestep.flatten()[0]) / 1000.0
        self.active = self.sigma_end <= sigma <= self.sigma_start
        self.control_stream = None
        if self.active:
            with comfy.model_prefetch.pause_malloc_graph():
                self.prepare_control_latent(x[0].shape)
        try:
            return executor(x, timestep, context, transformer_options, **kwargs)
        finally:
            self.control_stream = None
            self.pristine_stream = None

    def before_block(self, block_index, args):
        if not self.active or block_index != self.model_patch.model.injection_layers[0]:
            return
        self.pristine_stream = args["img"].clone()

    def after_block(self, block_index, args, out):
        if not self.active:
            return out
        control_index = self.model_patch.model.injection_layers.index(block_index)
        if control_index == 0:
            self.control_latent = self.control_latent.to(out["img"].device)
            self.control_stream = self.model_patch.model.init_stream(
                self.pristine_stream, self.control_latent, args["layout"], args["t_emb"])
            self.pristine_stream = None
        self.control_stream, skip = self.model_patch.model.step(
            control_index, self.control_stream, args["t_emb"], args["mod_segments"], args["rope_freqs"],
            transformer_options=args["transformer_options"])
        skip[args["layout"].audio_pos.to(skip.device)] = 0
        out["img"].add_(skip, alpha=self.strength)
        return out

    def to(self, device_or_dtype):
        if isinstance(device_or_dtype, torch.device):
            if self.control_latent is not None:
                self.control_latent = self.control_latent.to(device_or_dtype)
            self.control_stream = None
        return self

    def cleanup(self):
        self.control_latent = None
        self.control_latent_shape = None
        self.control_stream = None
        self.pristine_stream = None
        self.active = False

    def models(self):
        return [self.model_patch]

    def register(self, model):
        model.add_wrapper(comfy.patcher_extension.WrappersMP.DIFFUSION_MODEL, self.diffusion_model_wrapper)
        for block_index in self.model_patch.model.injection_layers:
            blocks_replace = model.model_options.get("transformer_options", {}).get("patches_replace", {}).get("dit", {})
            previous = blocks_replace.get(("double_block", block_index))
            model.set_model_patch_replace(
                MiniMaxH3FunControlBlockPatch(self, block_index, previous), "dit", "double_block", block_index)


class MiniMaxH3FunControlBlockPatch:
    def __init__(self, control_patch, block_index, previous):
        self.control_patch = control_patch
        self.block_index = block_index
        self.previous = previous

    def __call__(self, args, extra_args):
        with comfy.model_prefetch.pause_malloc_graph():
            self.control_patch.before_block(self.block_index, args)
        if self.previous is None:
            out = extra_args["original_block"](args)
        else:
            out = self.previous(args, extra_args)
        with comfy.model_prefetch.pause_malloc_graph():
            return self.control_patch.after_block(self.block_index, args, out)

    def to(self, device_or_dtype):
        self.control_patch.to(device_or_dtype)
        if hasattr(self.previous, "to"):
            self.previous = self.previous.to(device_or_dtype)
        return self

    def cleanup(self):
        self.control_patch.cleanup()
        if hasattr(self.previous, "cleanup"):
            self.previous.cleanup()

    def models(self):
        models = self.control_patch.models()
        if hasattr(self.previous, "models"):
            models += self.previous.models()
        return models


class MiniMaxH3FunControlNetApply(io.ComfyNode):
    @classmethod
    def define_schema(cls):
        return io.Schema(
            node_id="MiniMaxH3FunControlNetApply",
            description="Apply a MiniMax H3 Fun ControlNet to a text-to-video model as a model patch.",
            display_name="Apply MiniMax H3 Fun ControlNet",
            search_aliases=["minimax controlnet", "h3 controlnet", "video inpaint controlnet"],
            category="model/patch/minimax",
            inputs=[
                io.Model.Input("model"),
                io.ModelPatch.Input("model_patch"),
                io.Vae.Input("vae"),
                io.Float.Input("strength", default=1.0, min=0.0, max=10.0, step=0.01),
                io.Float.Input("start_percent", default=0.0, min=0.0, max=1.0, step=0.001, advanced=True),
                io.Float.Input("end_percent", default=1.0, min=0.0, max=1.0, step=0.001, advanced=True),
                io.Image.Input("control_video", optional=True),
                io.Mask.Input("mask", optional=True, tooltip="1 marks the regions to regenerate."),
                io.Image.Input("source_video", optional=True, tooltip="Video behind the mask; only read when a mask is given."),
            ],
            outputs=[io.Model.Output()],
        )

    @classmethod
    def execute(cls, model, model_patch, vae, strength, start_percent, end_percent,
                control_video=None, mask=None, source_video=None) -> io.NodeOutput:
        if strength == 0 or (control_video is None and mask is None):
            return io.NodeOutput(model)

        model_patched = model.clone()
        model_sampling = model.get_model_object("model_sampling")
        patch = MiniMaxH3FunControlPatch(
            model_patch,
            vae,
            control_video[..., :3].movedim(-1, 1) if control_video is not None else None,
            mask,
            source_video[..., :3].movedim(-1, 1) if mask is not None and source_video is not None else None,
            strength,
            float(model_sampling.percent_to_sigma(start_percent)),
            float(model_sampling.percent_to_sigma(end_percent)),
        )
        patch.register(model_patched)
        return io.NodeOutput(model_patched)


class MiniMaxH3Extension(ComfyExtension):
    async def get_node_list(self):
        return [
            EmptyMiniMaxH3LatentAV,
            MiniMaxH3ImageToVideo,
            MiniMaxH3ReferenceToVideo,
            MiniMaxH3SigmaShift,
            MiniMaxH3FunControlNetApply,
            ]


async def comfy_entrypoint() -> MiniMaxH3Extension:
    return MiniMaxH3Extension()
